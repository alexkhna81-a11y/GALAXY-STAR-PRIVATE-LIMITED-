const form=document.getElementById('bookingForm');
const toast=document.getElementById('toast');
form.addEventListener('submit',e=>{
  e.preventDefault();
  const bookingId='GS-'+Math.random().toString(36).slice(2,8).toUpperCase();
  const booking={
    id:bookingId,name:document.getElementById('name').value,
    phone:document.getElementById('phone').value,
    service:document.getElementById('service').value,
    date:document.getElementById('date').value,
    problem:document.getElementById('problem').value,
    createdAt:new Date().toISOString()
  };
  const list=JSON.parse(localStorage.getItem('galaxyStarBookings')||'[]');
  list.push(booking); localStorage.setItem('galaxyStarBookings',JSON.stringify(list));
  toast.textContent='Booking created successfully: '+bookingId;
  toast.style.display='block'; form.reset();
  setTimeout(()=>toast.style.display='none',5000);
});
